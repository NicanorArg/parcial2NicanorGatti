
package sistemadegestiondepersonajes;

import ModuloInventario.*;
import ModuloPersonaje.*;
import java.util.List;

public class SistemaDeGestionDePersonajes {

    public static void main(String[] args) {
        
        
        
        
        Inventario<Personaje> inventario = new Inventario();
        
        Personaje p1 = new Personaje(1, "Aragorn", Clase.GUERRERO, 40);
        Personaje p2 = new Personaje(2, "Legolas", Clase.ARQUERO, 45);
        Personaje p3 = new Personaje(3, "Gimli", Clase.GUERRERO, 39);
        Personaje p4 = new Personaje(4, "Gandalf", Clase.MAGO, 53);
        Personaje p5 = new Personaje(5, "Boromir", Clase.GUERRERO, 29);
        Personaje p6 = new Personaje(6, "Frodo", Clase.GUERRERO, 20);
        
        inventario.agregar(p1);
        inventario.agregar(p2);
        inventario.agregar(p3);
        inventario.agregar(p4);
        inventario.agregar(p5);
        inventario.agregar(p6);
        
        inventario.mostrar();
        
        inventario.ordenar();
        inventario.mostrar();
        
        inventario.ordenar((personaje1, personaje2) -> Integer.compare(personaje1.getNivel(), personaje2.getNivel()));
        inventario.mostrar();
        
        List<Personaje> filtrados = inventario.filtrar(personaje -> personaje.getClase().equals(Clase.MAGO));
        System.out.println(filtrados);
        
        inventario.guardarInventarioCSV("inventario.csv");
        
        Inventario cargado = Inventario.cargarInventarioPersonajesCsv("Inventario.csv");
        
    }
    
}
