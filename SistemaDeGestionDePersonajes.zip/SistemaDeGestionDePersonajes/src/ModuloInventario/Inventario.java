
package ModuloInventario;

import java.io.BufferedWriter;
import java.io.FileOutputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.io.ObjectOutputStream;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.function.Function;
import java.util.function.Predicate;
import ModuloPersonaje.*;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.ObjectInputStream;



public class Inventario<T extends CSVserializable> implements Serializable{
    
    private static final Long serialVersionUID = 1L;
    
    List<T> items = new ArrayList<>();
    
    public void agregar(T e){
        checkForNotNullValue(e);
        items.add(e);
    }
    
    public void quitar(T e){
        checkForNotNullValue(e);
        items.remove(e);
    }
    
    public void ordenar(){
        items.sort(null);
    }
    
    public void ordenar(Comparator<T> c){
        items.sort(c);
    }
    
    public List<T> filtrar(Predicate<T> p){
        List<T> aux = new ArrayList<>();
        for (T i: items){
            if(p.test(i)){
                aux.add(i);
            }
        }
        return aux;
    }
    
    public void transformar(Function<T, T> f){
        for(T i: items){
            f.apply(i);
        }
    }
    
    private void checkForNotNullValue(T e){
        if (e == null){
            throw new IllegalArgumentException();
        }
    }
    
    public void serializar(String ruta){
        
        try(ObjectOutputStream salida = new ObjectOutputStream(new FileOutputStream(ruta))){
            salida.writeObject(this);
        } 
        catch (IOException ex) {
            System.out.println(ex.getMessage());
        }
        
    }
    
    static public Inventario deserializar(String ruta){
        
        Inventario nuevoInventario = null;
        
        try(ObjectInputStream entrada = new ObjectInputStream(new FileInputStream(ruta))){
            nuevoInventario = (Inventario) entrada.readObject();
        }
        catch(IOException | ClassNotFoundException ex){
            System.out.println(ex.getMessage());
        }
        
        return nuevoInventario;
    }
    
    public void guardarInventarioCSV(String ruta){
        
        try(BufferedWriter escritor = new BufferedWriter(new FileWriter(ruta))){
            
            escritor.write("id,nombre,clase,nivel\n");
            for (T item: items){
                escritor.write(item.toCSV() + "\n");
            }
            
        }
        catch(IOException ex){
            System.out.println(ex.getMessage());
        }
        
    }
    
    public static Inventario<Personaje> cargarInventarioPersonajesCsv(String ruta){
        
        File csv = new File(ruta);
        Inventario nuevoInventario = new Inventario();
        
        try(BufferedReader lector = new BufferedReader(new FileReader(csv))){
            String linea;
            while((linea = lector.readLine())!= null){
            
                nuevoInventario.agregar(Personaje.fromCSV(linea));
                
            } 
            
        }
        catch(IOException ex){
            System.out.println(ex.getMessage());
        }
        return nuevoInventario;
    }
    
    public void mostrar(){
        System.out.println("En el inventario hay:");
        for(T i: items){
            System.out.println(i);
        }
        System.out.println("");
    }
    
}
