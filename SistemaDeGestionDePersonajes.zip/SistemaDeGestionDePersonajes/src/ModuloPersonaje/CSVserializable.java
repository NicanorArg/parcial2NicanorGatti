
package ModuloPersonaje;

public interface CSVserializable {
    
    String toCSV();
    
    
}
