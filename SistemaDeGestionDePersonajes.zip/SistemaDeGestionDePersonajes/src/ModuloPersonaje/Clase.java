
package ModuloPersonaje;

public enum Clase {
    GUERRERO,
    ARQUERO,
    MAGO
}
