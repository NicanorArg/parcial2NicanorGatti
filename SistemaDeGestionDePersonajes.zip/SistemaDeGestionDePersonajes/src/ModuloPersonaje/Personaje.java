
package ModuloPersonaje;

public class Personaje implements Comparable<Personaje>, CSVserializable{
    private int id;
    private String nombre;
    private Clase clase;
    private int nivel;

    public String getNombre() {
        return nombre;
    }

    public Clase getClase() {
        return clase;
    }

    public int getNivel() {
        return nivel;
    }

    public Personaje(int id, String nombre, Clase clase, int nivel) {
        this.id = id;
        this.nombre = nombre;
        this.clase = clase;
        this.nivel = nivel;
    }

    public static Personaje fromCSV(String CSV){
        CSV = CSV.substring(CSV.length() - 1);
        String[] atributos = CSV.split(",");
        
        int idValue = Integer.parseInt(atributos[0]);
        String nombreValue = atributos[1];
        Clase claseValue = Clase.valueOf(atributos[2]);
        int nivelValue = Integer.parseInt(atributos[3]);
        return new Personaje(idValue, nombreValue, claseValue, nivelValue);
        
    }
    
    @Override
    public String toString() {
        return "Id: " + id + ", nombre: " + nombre + ", clase: " + clase + ", nivel: " + nivel;
    }

    @Override
    public int compareTo(Personaje p) {
        return nombre.compareTo(p.getNombre());
    }

    @Override
    public String toCSV() {
        return id + "," + nombre + "," + clase + "," + nivel;
    }
    
    
    
}
